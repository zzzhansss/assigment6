package com.pattern;

public class Runner {
    public static void main(String[] args){
        Game game = new Game();

        game.setActivity(new Wizard());
        game.executeActivity();

        game.setActivity(new Muggle());
        game.executeActivity();

        game.setActivity(new Elf());
        game.executeActivity();

        game.setActivity(new Giant());
        game.executeActivity();

        game.setActivity(new Centaur());
        game.executeActivity();

        game.setActivity(new Ghost());
        game.executeActivity();

        game.setActivity(new Hippogryph());
        game.executeActivity();
    }
}
