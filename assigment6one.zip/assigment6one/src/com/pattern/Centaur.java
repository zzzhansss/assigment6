package com.pattern;

public class Centaur implements Activity {
    @Override
    public void justDoIt() {
        System.out.println("walk and run");
    }

    @Override
    public void walk() {
        System.out.println("walk");

    }

    @Override
    public void fly() {
        System.out.println("no");
    }
}
