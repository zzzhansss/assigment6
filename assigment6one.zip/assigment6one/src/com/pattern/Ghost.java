package com.pattern;

public class Ghost implements Activity {
    @Override
    public void justDoIt() {
        System.out.println("fly");
    }

    @Override
    public void walk() {
        System.out.println("no");
    }

    @Override
    public void fly() {
        System.out.println("fly");
    }
}
