package com.pattern;

public class Hippogryph implements Activity {
    @Override
    public void justDoIt() {
        System.out.println("walk and fly");
    }

    @Override
    public void walk() {
        System.out.println("walks");
    }

    @Override
    public void fly() {
        System.out.println("fly with wings");
    }
}
