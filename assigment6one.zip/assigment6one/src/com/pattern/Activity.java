package com.pattern;

public interface Activity {
    public void justDoIt();
    public void walk();

    public default void fly() {

    }
}
