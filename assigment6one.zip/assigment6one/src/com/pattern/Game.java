package com.pattern;

public class Game {
    Activity activity;

    public void setActivity(Activity activity) {
        this.activity = activity;
    }

    public void executeActivity(){
        activity.justDoIt();
        activity.walk();
        activity.fly();
    }
}
