package com.pattern;

 class Wizard implements Activity {
     @Override
     public void justDoIt() {
         System.out.println("walk and fly");
     }

     @Override
    public void walk() {
        System.out.println("walking as people ");
    }

    @Override
    public void fly(){
        System.out.println("using a broom");
    }
}
