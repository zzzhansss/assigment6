package com.pattern;

public class Muggle implements Activity {

    @Override
    public void justDoIt() {
        System.out.println("just walk");
    }

    @Override
    public void walk() {
        System.out.println("walk");
    }

    @Override
    public void fly() {
        System.out.println("no");
    }
}
