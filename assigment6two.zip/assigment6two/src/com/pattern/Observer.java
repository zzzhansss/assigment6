package com.pattern;

import java.util.List;

public interface Observer {
    public void sort(List<String> posts);
}
