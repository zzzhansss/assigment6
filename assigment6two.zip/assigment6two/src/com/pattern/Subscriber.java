package com.pattern;

import java.util.List;


public class Subscriber implements Observer {
    String name;

    public Subscriber(String name) {
        this.name = name;
    }

    @Override
    public void sort(List<String> posts) {
        System.out.println("Dear"+" "+name+"\nWe have some changes:\n"+posts+"\n");

    }
}
