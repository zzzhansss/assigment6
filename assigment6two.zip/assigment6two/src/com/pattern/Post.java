package com.pattern;

public class Post {
    public static void main(String[] args) {
        Developer post = new Developer();

        post.addPost("first post");
        post.addPost("second post");

        Observer firstSubscriber = new Subscriber("Zhansaya");
        Observer secondSubscriber = new Subscriber("Aliya");

        post.addObserver(firstSubscriber);
        post.addObserver(secondSubscriber);

        post.addPost("third post");
        post.addPost(("fourth post"));
        post.removePost("second post");

    }
    }
